package habitquest.avatar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
@EnableAutoConfiguration(
    exclude = {
      // org.springframework.cloud.stream.binder.kafka.config.KafkaBinderConfiguration.class,
      org.springframework.cloud.stream.config.BindingServiceConfiguration.class
    })
class AvatarServiceApplicationTests {

  @Test
  void contextLoads() {}
}
