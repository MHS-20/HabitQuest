package habitquest.avatar.domain.stats;

public record Strength(BaseStat stat) implements AvatarStat {

  public Strength(Integer value) {
    this(new BaseStat("strength", value));
  }

  @Override
  public Strength increment() {
    return new Strength(stat.increment());
  }

  @Override
  public Integer value() {
    return stat.value();
  }

  @Override
  public String name() {
    return stat.name();
  }
}
