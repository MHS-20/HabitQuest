package habitquest.avatar.infrastructure;

import habitquest.avatar.application.AvatarNotFoundExpection;
import habitquest.avatar.application.AvatarService;
import habitquest.avatar.domain.avatar.*;
import habitquest.avatar.domain.items.EquippedItems;
import habitquest.avatar.domain.items.Inventory;
import habitquest.avatar.domain.items.Item;
import habitquest.avatar.domain.stats.AvatarStats;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/** REST controller for avatar-service. Base path: /avatars */
@RestController
@RequestMapping("/avatars")
public class AvatarController {

  private final AvatarService avatarService;

  public AvatarController(AvatarService avatarService) {
    this.avatarService = avatarService;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // CRUD
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * POST /avatars Create a new avatar with the given name. Returns 201 Created with the generated
   * avatar ID.
   */
  @PostMapping
  public ResponseEntity<String> createAvatar(@RequestBody CreateAvatarRequest request) {
    String id = avatarService.createAvatar(request.name());
    return ResponseEntity.status(HttpStatus.CREATED).body(id);
  }

  /** GET /avatars/{id} Retrieve a full avatar by ID. */
  @GetMapping("/{id}")
  public ResponseEntity<Avatar> getAvatar(@PathVariable String id) {
    try {
      Avatar avatar = avatarService.getAvatarById(id);
      return ResponseEntity.ok(avatar);
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** PUT /avatars/{id} Replace a full avatar document. */
  @PutMapping("/{id}")
  public ResponseEntity<Void> updateAvatar(
      @PathVariable String id, @RequestBody Avatar updatedAvatar) {
    try {
      avatarService.updateAvatar(id, updatedAvatar);
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** DELETE /avatars/{id} Remove an avatar. */
  @DeleteMapping("/{id}")
  public ResponseEntity<Void> deleteAvatar(@PathVariable String id) {
    try {
      avatarService.deleteAvatar(id);
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Read projections
  // Used by guild-service (BattleStarted) and marketplace-service (ItemBought)
  // ─────────────────────────────────────────────────────────────────────────

  /** GET /avatars/{id}/name */
  @GetMapping("/{id}/name")
  public ResponseEntity<String> getName(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getName(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** GET /avatars/{id}/money Used by marketplace-service before ItemBought to verify balance. */
  @GetMapping("/{id}/money")
  public ResponseEntity<Money> getMoney(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getMoney(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** GET /avatars/{id}/inventory Used by marketplace-service (ItemBought / ItemSold). */
  @GetMapping("/{id}/inventory")
  public ResponseEntity<Inventory> getInventory(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getInventory(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** GET /avatars/{id}/equipped-items */
  @GetMapping("/{id}/equipped-items")
  public ResponseEntity<EquippedItems> getEquippedItems(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getEquippedItems(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** GET /avatars/{id}/experience */
  @GetMapping("/{id}/experience")
  public ResponseEntity<Experience> getExperience(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getExperience(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** GET /avatars/{id}/level Used by guild-service (BattleStarted) to snapshot member levels. */
  @GetMapping("/{id}/level")
  public ResponseEntity<Level> getLevel(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getLevel(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** GET /avatars/{id}/health */
  @GetMapping("/{id}/health")
  public ResponseEntity<AvatarHealth> getHealth(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getHealth(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /**
   * GET /avatars/{id}/mana Used by guild-service (BattleStarted, SpellCasted) to read current mana.
   */
  @GetMapping("/{id}/mana")
  public ResponseEntity<AvatarMana> getMana(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getMana(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /**
   * GET /avatars/{id}/stats Used by guild-service (BattleStarted, AttackPerformed) to read combat
   * stats.
   */
  @GetMapping("/{id}/stats")
  public ResponseEntity<AvatarStats> getAvatarStats(@PathVariable String id) {
    try {
      return ResponseEntity.ok(avatarService.getAvatarStats(id));
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Identity mutations
  // ─────────────────────────────────────────────────────────────────────────

  /** PATCH /avatars/{id}/name */
  @PatchMapping("/{id}/name")
  public ResponseEntity<Void> updateName(
      @PathVariable String id, @RequestBody UpdateNameRequest request) {
    try {
      avatarService.updateName(id, request.name());
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Money mutations
  // Used by tracking-service (HabitAttended), quest-service (QuestCompleted /
  // QuestNotCompleted), guild-service (BattleWon / BattleLost),
  // marketplace-service (ItemBought / ItemSold)
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * POST /avatars/{id}/money/spend Deduct money from the avatar (e.g. ItemBought, BattleLost
   * penalty). Body: { "amount": 100 }
   */
  @PostMapping("/{id}/money/spend")
  public ResponseEntity<Void> spendMoney(
      @PathVariable String id, @RequestBody AmountRequest request) {
    try {
      avatarService.spendMoney(id, request.amount());
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** POST /avatars/{id}/money/earn Credit money to the avatar (e.g. ItemSold, BattleWon reward). */
  @PostMapping("/{id}/money/earn")
  public ResponseEntity<Void> earnMoney(
      @PathVariable String id, @RequestBody AmountRequest request) {
    try {
      avatarService.earnMoney(id, request.amount());
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Inventory mutations
  // Used by marketplace-service (ItemBought / ItemSold)
  // ─────────────────────────────────────────────────────────────────────────

  /** POST /avatars/{id}/inventory/add Add an item to the avatar's inventory (ItemBought). */
  @PostMapping("/{id}/inventory/add")
  public ResponseEntity<Void> addToInventory(@PathVariable String id, @RequestBody Item item) {
    try {
      avatarService.addToInventory(id, item);
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** POST /avatars/{id}/inventory/remove Remove an item from the avatar's inventory (ItemSold). */
  @PostMapping("/{id}/inventory/remove")
  public ResponseEntity<Void> removeItem(@PathVariable String id, @RequestBody Item item) {
    avatarService.removeItem(id, item);
    return ResponseEntity.noContent().build();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Equipment mutations
  // ─────────────────────────────────────────────────────────────────────────

  /** POST /avatars/{id}/equipped-items/equip */
  @PostMapping("/{id}/equipped-items/equip")
  public ResponseEntity<Void> equipItem(@PathVariable String id, @RequestBody Item item) {
    avatarService.equipItem(id, item);
    return ResponseEntity.noContent().build();
  }

  /** POST /avatars/{id}/equipped-items/unequip */
  @PostMapping("/{id}/equipped-items/unequip")
  public ResponseEntity<Void> unequipItem(@PathVariable String id, @RequestBody Item item) {
    avatarService.unequipItem(id, item);
    return ResponseEntity.noContent().build();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Health mutations
  // Used by tracking-service (HabitAttended +HP / HabitNotAttended -HP),
  // quest-service (QuestNotCompleted -HP), guild-service (BattleLost -HP)
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * POST /avatars/{id}/health/damage Apply damage to the avatar. Triggers Dead event internally
   * when HP = 0.
   */
  @PostMapping("/{id}/health/damage")
  public ResponseEntity<Void> applyDamage(
      @PathVariable String id, @RequestBody AmountRequest request) {
    avatarService.applyDamage(id, request.amount());
    return ResponseEntity.noContent().build();
  }

  /** POST /avatars/{id}/health/heal Restore HP to the avatar (HabitAttended +HP). */
  @PostMapping("/{id}/health/heal")
  public ResponseEntity<Void> healAvatar(
      @PathVariable String id, @RequestBody AmountRequest request) {
    avatarService.healAvatar(id, request.amount());
    return ResponseEntity.noContent().build();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Mana mutations
  // Used by guild-service (AttackPerformed -mana, SpellCasted -mana)
  // ─────────────────────────────────────────────────────────────────────────

  /** POST /avatars/{id}/mana/spend Deduct mana (AttackPerformed, SpellCasted). */
  @PostMapping("/{id}/mana/spend")
  public ResponseEntity<Void> spendMana(
      @PathVariable String id, @RequestBody AmountRequest request) {
    avatarService.spendMana(id, request.amount());
    return ResponseEntity.noContent().build();
  }

  /** POST /avatars/{id}/mana/restore */
  @PostMapping("/{id}/mana/restore")
  public ResponseEntity<Void> restoreMana(
      @PathVariable String id, @RequestBody AmountRequest request) {
    avatarService.restoreMana(id, request.amount());
    return ResponseEntity.noContent().build();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Experience / levelling
  // Used by tracking-service (HabitAttended +XP), quest-service (QuestCompleted +XP),
  // guild-service (BattleWon +XP). Internally fires LevelUpped event when threshold crossed.
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * POST /avatars/{id}/experience/grant Grant XP to the avatar. Triggers LevelUpped event
   * internally if level threshold crossed.
   */
  @PostMapping("/{id}/experience/grant")
  public ResponseEntity<Void> grantExperience(
      @PathVariable String id, @RequestBody AmountRequest request) {
    avatarService.grantExperience(id, request.amount());
    return ResponseEntity.noContent().build();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Stat point allocation
  // Triggered after LevelUpped — player chooses which stat to increase
  // ─────────────────────────────────────────────────────────────────────────

  /** POST /avatars/{id}/stats/strength/increase */
  @PostMapping("/{id}/stats/strength/increase")
  public ResponseEntity<Void> increaseStrength(@PathVariable String id) {
    try {
      avatarService.increaseStrength(id);
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** POST /avatars/{id}/stats/defense/increase */
  @PostMapping("/{id}/stats/defense/increase")
  public ResponseEntity<Void> increaseDefense(@PathVariable String id) {
    try {
      avatarService.increaseDefense(id);
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  /** POST /avatars/{id}/stats/intelligence/increase */
  @PostMapping("/{id}/stats/intelligence/increase")
  public ResponseEntity<Void> increaseIntelligence(@PathVariable String id) {
    try {
      avatarService.increaseIntelligence(id);
      return ResponseEntity.noContent().build();
    } catch (AvatarNotFoundExpection e) {
      return ResponseEntity.notFound().build();
    }
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Request / response records
  // ─────────────────────────────────────────────────────────────────────────

  public record CreateAvatarRequest(String name) {}

  public record UpdateNameRequest(String name) {}

  /** Generic body for any single integer amount (XP, HP, mana, money). */
  public record AmountRequest(Integer amount) {}
}
