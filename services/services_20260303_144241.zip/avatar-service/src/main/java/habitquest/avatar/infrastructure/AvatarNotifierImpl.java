package habitquest.avatar.infrastructure;

import common.hexagonal.Adapter;
import habitquest.avatar.application.AvatarNotifier;
import habitquest.avatar.domain.events.Dead;
import habitquest.avatar.domain.events.LevelUpped;
import habitquest.avatar.domain.events.SkillPointAssigned;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

/**
 * Outbound adapter that fulfils the AvatarNotifier port.
 *
 * <p>notification-service → Kafka via Spring Cloud Stream (StreamBridge) marketplace-service → REST
 * via RestClient (unchanged)
 *
 * <p>Kafka bindings (configure in application.yml):
 *
 * <p>spring: cloud: stream: bindings: avatar-dead-out-0: destination: avatar.dead
 * avatar-level-upped-out-0: destination: avatar.level-upped avatar-skill-point-assigned-out-0:
 * destination: avatar.skill-point-assigned kafka: binder: brokers: localhost:9092
 *
 * <p>notification-service consumes those three topics and turns each message into a push
 * notification for the affected avatar.
 *
 * <p>Dead [diagram section 1] → topic avatar.dead { "avatarId": "...", "message": "Your avatar has
 * died!" }
 *
 * <p>LevelUpped [diagram section 2] → topic avatar.level-upped { "avatarId": "...", "message":
 * "Level up! Level: <n>" } → POST marketplace-service /marketplaces/{id}/items/update-by-level →
 * POST marketplace-service /marketplaces/{id}/items/unlock-by-level
 *
 * <p>SkillPointAssigned [not in diagram — notification only] → topic avatar.skill-point-assigned {
 * "avatarId": "...", "message": "Skill point assigned to <stat>!" }
 */
@Adapter
@Service
public class AvatarNotifierImpl implements AvatarNotifier {

  // Binding names must match the keys defined under spring.cloud.stream.bindings
  private static final String BINDING_DEAD = "avatar-dead-out-0";
  private static final String BINDING_LEVEL_UPPED = "avatar-level-upped-out-0";
  private static final String BINDING_SKILL_POINT = "avatar-skill-point-assigned-out-0";

  private final StreamBridge streamBridge;
  private final RestClient marketplaceClient;
  private final String marketplaceId;

  public AvatarNotifierImpl(
      StreamBridge streamBridge,
      @Value("${services.marketplace.base-url}") String marketplaceBaseUrl,
      @Value("${services.marketplace.id}") String marketplaceId) {
    this.streamBridge = streamBridge;
    this.marketplaceClient = RestClient.builder().baseUrl(marketplaceBaseUrl).build();
    this.marketplaceId = marketplaceId;
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Dead  [diagram section 1]
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Publishes a notification event to the avatar.dead Kafka topic. notification-service consumes
   * this and delivers the push to the user.
   *
   * <p>Diagram: avatar-service --«event»--> notification-service sendNotification(avatarId, "Your
   * avatar has died!")
   */
  @Override
  public void notifyDead(Dead event) {
    streamBridge.send(
        BINDING_DEAD, new NotificationMessage(event.avatarId(), "Your avatar has died!"));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // LevelUpped  [diagram section 2]
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Publishes a level-up notification to Kafka, then synchronously updates the marketplace
   * catalogue over REST so newly available items are immediately reflected.
   *
   * <p>Diagram: avatar-service --«event»--> notification-service sendNotification(avatarId, "Level
   * up! Level: " + newLevel)
   *
   * <p>Diagram: avatar-service --> marketplace-service updateItems(avatarLevel)
   * unlockItemsByLevel(avatarLevel)
   */
  @Override
  public void notifyLevelUpped(LevelUpped event) {
    int newLevel = event.newLevel().levelNumber();

    // 1. Notify the avatar owner via Kafka
    streamBridge.send(
        BINDING_LEVEL_UPPED,
        new NotificationMessage(event.avatarId(), "Level up! Level: " + newLevel));

    // 2. Update available items for the new level in the marketplace (REST)
    marketplaceClient
        .post()
        .uri("/marketplaces/{marketplaceId}/items/update-by-level", marketplaceId)
        .body(new AvatarLevelRequest(newLevel))
        .retrieve()
        .toBodilessEntity();

    // 3. Unlock items gated behind this level threshold (REST)
    marketplaceClient
        .post()
        .uri("/marketplaces/{marketplaceId}/items/unlock-by-level", marketplaceId)
        .body(new AvatarLevelRequest(newLevel))
        .retrieve()
        .toBodilessEntity();
  }

  // ─────────────────────────────────────────────────────────────────────────
  // SkillPointAssigned  [no outbound call in diagram — notification only]
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Publishes a skill-point notification to Kafka. The diagram shows no further outbound calls for
   * this event.
   */
  @Override
  public void notifySkillPointAssigned(SkillPointAssigned event) {
    streamBridge.send(
        BINDING_SKILL_POINT,
        new NotificationMessage(
            event.avatarId(), "Skill point assigned to " + event.stat().name() + "!"));
  }

  // ─────────────────────────────────────────────────────────────────────────
  // Payload records
  // ─────────────────────────────────────────────────────────────────────────

  /**
   * Kafka message payload consumed by notification-service. recipientId — avatar ID that receives
   * the push notification. message — human-readable text shown in the UML diagram.
   */
  private record NotificationMessage(String recipientId, String message) {}

  /** REST body for marketplace item update / unlock endpoints. */
  private record AvatarLevelRequest(Integer avatarLevel) {}
}
