package habitquest.avatar.domain.stats;

public record BaseStat(String name, Integer value) implements AvatarStat {
  public BaseStat {
    if (value < 0) {
      throw new IllegalArgumentException("Stat value cannot be negative");
    }

    if (name == null || name.isBlank()) {
      throw new IllegalArgumentException("Stat name cannot be null or blank");
    }
  }

  public BaseStat increment() {
    return new BaseStat(name, value + 1);
  }
}
