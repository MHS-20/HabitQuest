package habitquest.marketplace.domain.events;

import habitquest.marketplace.domain.items.Item;

public record ItemSold(String marketplaceId, Item item, String avatarId)
    implements MarketplaceEvent {}
