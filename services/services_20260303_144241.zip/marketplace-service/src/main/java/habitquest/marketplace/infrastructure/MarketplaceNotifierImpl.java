package habitquest.marketplace.infrastructure;

import common.hexagonal.Adapter;
import habitquest.marketplace.application.MarketplaceNotifier;
import habitquest.marketplace.domain.events.ItemBought;
import habitquest.marketplace.domain.events.ItemSold;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

/**
 * Outbound adapter that fulfils the MarketplaceNotifier port.
 *
 * avatar-service  →  REST via RestClient (synchronous — diagram shows direct arrows)
 *
 * The REST calls must complete before the transaction is considered done:
 *   ItemBought requires balance verification and inventory/money update.
 *   ItemSold   requires inventory removal and money credit.
 * Kafka is used only to publish the event for other downstream consumers
 * (analytics, audit, etc.) after the REST operations succeed.
 *
 * Kafka bindings (configure in application.yml):
 *
 *   spring:
 *     cloud:
 *       stream:
 *         bindings:
 *           item-bought-out-0:
 *             destination: marketplace.item-bought
 *           item-sold-out-0:
 *             destination: marketplace.item-sold
 *         kafka:
 *           binder:
 *             brokers: localhost:9092
 *
 * ItemBought  [diagram section 1]
 *   → GET  avatar-service /avatars/{avatarId}/money           [balance check]
 *   → POST avatar-service /avatars/{avatarId}/money/spend     [-item.price]
 *   → POST avatar-service /avatars/{avatarId}/inventory/add   [+item]
 *   → topic marketplace.item-bought                           [downstream consumers]
 *
 * ItemSold    [diagram section 2]
 *   → POST avatar-service /avatars/{avatarId}/inventory/remove [-item]
 *   → POST avatar-service /avatars/{avatarId}/money/earn       [+item.sellPrice]
 *   → topic marketplace.item-sold                              [downstream consumers]
 */
@Service
@Adapter
public class MarketplaceNotifierImpl implements MarketplaceNotifier {

    private static final String BINDING_ITEM_BOUGHT = "item-bought-out-0";
    private static final String BINDING_ITEM_SOLD   = "item-sold-out-0";

    private final StreamBridge streamBridge;
    private final RestClient   avatarClient;

    public MarketplaceNotifierImpl(
            StreamBridge streamBridge,
            @Value("${services.avatar.base-url}") String avatarBaseUrl) {
        this.streamBridge = streamBridge;
        this.avatarClient = RestClient.builder().baseUrl(avatarBaseUrl).build();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ItemBought  [diagram section 1]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Verifies the avatar has sufficient funds, deducts the item price,
     * adds the item to the avatar's inventory, then publishes the event.
     *
     * Diagram:
     *   getMoney(avatarId)                         [verify balance]
     *   updateMoney(avatarId, -item.price)
     *   updateInventory(avatarId, inventory + item)
     *
     * If the avatar has insufficient funds, avatar-service returns an error
     * which propagates as InsufficientFundsException before any mutation occurs.
     */
    @Override
    public void notifyItemBought(ItemBought e) {
        // 1. Verify balance — throws if insufficient funds
        avatarClient.get()
                .uri("/avatars/{id}/money", e.avatarId())
                .retrieve()
                .toBodilessEntity();

        // 2. Deduct item price from avatar's wallet
        avatarClient.post()
                .uri("/avatars/{id}/money/spend", e.avatarId())
                .body(new AmountRequest(e.item().price().amount()))
                .retrieve()
                .toBodilessEntity();

        // 3. Add item to avatar's inventory
        avatarClient.post()
                .uri("/avatars/{id}/inventory/add", e.avatarId())
                .body(e.item())
                .retrieve()
                .toBodilessEntity();

        // 4. Publish event for downstream consumers (analytics, audit, etc.)
        streamBridge.send(BINDING_ITEM_BOUGHT, e);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // ItemSold  [diagram section 2]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Removes the item from the avatar's inventory, credits the sell price,
     * then publishes the event.
     *
     * Diagram:
     *   updateInventory(avatarId, inventory - item)
     *   updateMoney(avatarId, +item.sellPrice)
     */
    @Override
    public void notifyItemSold(ItemSold e) {
        // 1. Remove item from avatar's inventory
        avatarClient.post()
                .uri("/avatars/{id}/inventory/remove", e.avatarId())
                .body(e.item())
                .retrieve()
                .toBodilessEntity();

        // 2. Credit sell price to avatar's wallet
        avatarClient.post()
                .uri("/avatars/{id}/money/earn", e.avatarId())
                .body(new AmountRequest(e.item().price().amount()   ))
                .retrieve()
                .toBodilessEntity();

        // 3. Publish event for downstream consumers (analytics, audit, etc.)
        streamBridge.send(BINDING_ITEM_SOLD, e);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Payload records
    // ─────────────────────────────────────────────────────────────────────────

    /** REST body for avatar-service amount endpoints (money spend / earn). */
    private record AmountRequest(Integer amount) {}
}
