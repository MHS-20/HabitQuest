package habitquest.marketplace.domain.events;

import habitquest.marketplace.domain.items.Item;

public record ItemBought(String marketplaceId, Item item, String avatarId)
    implements MarketplaceEvent {}
