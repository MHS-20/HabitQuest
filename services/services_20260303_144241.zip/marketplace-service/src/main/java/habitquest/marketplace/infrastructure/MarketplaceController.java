package habitquest.marketplace.infrastructure;

import habitquest.marketplace.application.ItemNotFoundException;
import habitquest.marketplace.application.MarketplaceNotFoundException;
import habitquest.marketplace.application.MarketplaceService;
import habitquest.marketplace.domain.Marketplace;
import habitquest.marketplace.domain.items.*;
import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for marketplace-service.
 * Base path: /marketplaces/{marketplaceId}
 */
@RestController
@RequestMapping("/marketplaces/{marketplaceId}")
public class MarketplaceController {

    private final MarketplaceService marketplaceService;

    public MarketplaceController(MarketplaceService marketplaceService) {
        this.marketplaceService = marketplaceService;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Marketplace root
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * GET /marketplaces/{marketplaceId}
     * Retrieve the full marketplace document (metadata + all items).
     */
    @GetMapping
    public ResponseEntity<Marketplace> getMarketplace(
            @PathVariable String marketplaceId) {
        try {
            return ResponseEntity.ok(marketplaceService.getMarketplace(marketplaceId));
        } catch (MarketplaceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Item catalogue — read projections
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * GET /marketplaces/{marketplaceId}/items
     * List all items available in the marketplace.
     */
    @GetMapping("/items")
    public ResponseEntity<List<Item>> getItems(
            @PathVariable String marketplaceId) {
        try {
            return ResponseEntity.ok(marketplaceService.getItems(marketplaceId));
        } catch (MarketplaceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /marketplaces/{marketplaceId}/items/{itemName}
     * Look up a single item by name.
     * Used by the buy flow to display item details (price, stats) before purchase.
     *
     * [diagram section 1 — ItemBought: client fetches item info before calling /buy]
     */
    @GetMapping("/items/{itemName}")
    public ResponseEntity<Item> getItemByName(
            @PathVariable String marketplaceId,
            @PathVariable String itemName) {
        try {
            return ResponseEntity.ok(marketplaceService.getItemByName(marketplaceId, itemName));
        } catch (MarketplaceNotFoundException | ItemNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /marketplaces/{marketplaceId}/items/armors
     * List all armors available in the marketplace.
     */
    @GetMapping("/items/armors")
    public ResponseEntity<List<Armor>> getArmors(
            @PathVariable String marketplaceId) {
        try {
            return ResponseEntity.ok(marketplaceService.getArmors(marketplaceId));
        } catch (MarketplaceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /marketplaces/{marketplaceId}/items/weapons
     * List all weapons available in the marketplace.
     */
    @GetMapping("/items/weapons")
    public ResponseEntity<List<Weapon>> getWeapons(
            @PathVariable String marketplaceId) {
        try {
            return ResponseEntity.ok(marketplaceService.getWeapons(marketplaceId));
        } catch (MarketplaceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /marketplaces/{marketplaceId}/items/potions
     * List all potions (health + mana) available in the marketplace.
     */
    @GetMapping("/items/potions")
    public ResponseEntity<List<Potion>> getPotions(
            @PathVariable String marketplaceId) {
        try {
            return ResponseEntity.ok(marketplaceService.getPotions(marketplaceId));
        } catch (MarketplaceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /marketplaces/{marketplaceId}/items/potions/health
     * List health potions only.
     */
    @GetMapping("/items/potions/health")
    public ResponseEntity<List<HealthPotion>> getHealthPotions(
            @PathVariable String marketplaceId) {
        try {
            return ResponseEntity.ok(marketplaceService.getHealthPotions(marketplaceId));
        } catch (MarketplaceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /marketplaces/{marketplaceId}/items/potions/mana
     * List mana potions only.
     */
    @GetMapping("/items/potions/mana")
    public ResponseEntity<List<ManaPotion>> getManaPotions(
            @PathVariable String marketplaceId) {
        try {
            return ResponseEntity.ok(marketplaceService.getManaPotions(marketplaceId));
        } catch (MarketplaceNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Commands — buy / sell
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * POST /marketplaces/{marketplaceId}/items/{itemName}/buy
     * Avatar purchases an item from the marketplace.
     *
     * Internally fires ItemBought → MarketplaceObserver →
     *   avatar-service.getMoney(avatarId)                  [verify balance]
     *   avatar-service.spendMoney(avatarId, item.price)
     *   avatar-service.addToInventory(avatarId, item)
     * If the avatar has insufficient funds the observer throws
     * InsufficientFundsException, which propagates as 422.
     *
     * [diagram section 1 — ItemBought]
     */
    @PostMapping("/items/{itemName}/buy")
    public ResponseEntity<Void> buyItem(
            @PathVariable String marketplaceId,
            @PathVariable String itemName,
            @RequestBody BuyItemRequest request) {
        try {
            marketplaceService.buyItem(marketplaceId, itemName, request.avatarId());
            return ResponseEntity.noContent().build();
        } catch (MarketplaceNotFoundException | ItemNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * POST /marketplaces/{marketplaceId}/items/{itemName}/sell
     * Avatar sells an item back to the marketplace.
     *
     * Internally fires ItemSold → MarketplaceObserver →
     *   avatar-service.removeItem(avatarId, item)
     *   avatar-service.earnMoney(avatarId, item.sellPrice)
     *
     * [diagram section 2 — ItemSold]
     */
    @PostMapping("/items/{itemName}/sell")
    public ResponseEntity<Void> sellItem(
            @PathVariable String marketplaceId,
            @PathVariable String itemName,
            @RequestBody SellItemRequest request) {
        try {
            marketplaceService.sellItem(marketplaceId, itemName, request.avatarId());
            return ResponseEntity.noContent().build();
        } catch (MarketplaceNotFoundException | ItemNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Request records
    // ─────────────────────────────────────────────────────────────────────────

    /** Body for POST .../buy — identifies which avatar is making the purchase. */
    public record BuyItemRequest(String avatarId) {}

    /** Body for POST .../sell — identifies which avatar is selling the item. */
    public record SellItemRequest(String avatarId) {}
}