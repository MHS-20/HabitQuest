package habitquest.marketplace;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarketplaceServiceApplicationTests {

  @Test
  void contextLoads() {}
}
