package habitquest.guild.infrastructure;

import habitquest.guild.application.BattleNotFoundException;
import habitquest.guild.application.BattleService;
import habitquest.guild.domain.battle.Battle;
import habitquest.guild.domain.battle.BattleStatus;
import habitquest.guild.domain.battle.boss.BossEnemy;
import habitquest.guild.domain.battle.boss.BossStatus;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * REST controller for battle operations within guild-service.
 * Base path: /guilds/{guildId}/battles
 */
@RestController
@RequestMapping("/guilds/{guildId}/battles")
public class BattleController {

    private final BattleService battleService;

    public BattleController(BattleService battleService) {
        this.battleService = battleService;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Battle lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * POST /guilds/{guildId}/battles
     * Start a new battle for this guild against a boss.
     * Internally fires BattleStarted
     * Returns 201 Created with the generated battle ID.
     */
    @PostMapping
    public ResponseEntity<String> createBattle(
            @PathVariable String guildId,
            @RequestBody CreateBattleRequest request) {
        String battleId = battleService.createBattle(guildId, request.boss(), request.numOfTurns());
        return ResponseEntity.status(HttpStatus.CREATED).body(battleId);
    }

    /**
     * GET /guilds/{guildId}/battles
     * List all battles belonging to this guild.
     */
    @GetMapping
    public ResponseEntity<List<Battle>> getBattlesByGuild(@PathVariable String guildId) {
        return ResponseEntity.ok(battleService.getBattlesByGuild(guildId));
    }

    /**
     * GET /guilds/{guildId}/battles/in-progress
     * Returns whether the guild currently has an ongoing battle.
     * Useful for pre-flight checks before allowing a new battle to start.
     */
    @GetMapping("/in-progress")
    public ResponseEntity<Boolean> hasBattleInProgress(@PathVariable String guildId) {
        return ResponseEntity.ok(battleService.hasBattleInProgress(guildId));
    }

    /**
     * GET /guilds/{guildId}/battles/{battleId}
     * Retrieve a single battle by ID.
     */
    @GetMapping("/{battleId}")
    public ResponseEntity<Battle> getBattle(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            return ResponseEntity.ok(battleService.getBattleById(battleId));
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * DELETE /guilds/{guildId}/battles/{battleId}
     * Remove a battle record.
     */
    @DeleteMapping("/{battleId}")
    public ResponseEntity<Void> deleteBattle(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            battleService.deleteBattle(battleId);
            return ResponseEntity.noContent().build();
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Boss info
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * GET /guilds/{guildId}/battles/{battleId}/boss
     * Retrieve the boss definition for this battle.
     */
    @GetMapping("/{battleId}/boss")
    public ResponseEntity<BossEnemy> getBoss(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            return ResponseEntity.ok(battleService.getBoss(battleId));
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /guilds/{guildId}/battles/{battleId}/boss/health
     * Retrieve the boss's current remaining health.
     */
    @GetMapping("/{battleId}/boss/health")
    public ResponseEntity<BossStatus> getBossRemainingHealth(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            return ResponseEntity.ok(battleService.getBossRemainingHealth(battleId));
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Battle status
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * GET /guilds/{guildId}/battles/{battleId}/status
     * Retrieve the full battle status (ONGOING, WON, LOST).
     */
    @GetMapping("/{battleId}/status")
    public ResponseEntity<BattleStatus> getBattleStatus(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            return ResponseEntity.ok(battleService.getBattleStatus(battleId));
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /guilds/{guildId}/battles/{battleId}/over
     * Returns true if the battle has concluded (won or lost).
     */
    @GetMapping("/{battleId}/over")
    public ResponseEntity<Boolean> isBattleOver(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            return ResponseEntity.ok(battleService.isBattleOver(battleId));
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * GET /guilds/{guildId}/battles/{battleId}/won
     * Returns true if the battle ended in a victory.
     */
    @GetMapping("/{battleId}/won")
    public ResponseEntity<Boolean> isBattleWon(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            return ResponseEntity.ok(battleService.isBattleWon(battleId));
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Turn management
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * GET /guilds/{guildId}/battles/{battleId}/turns
     * Retrieve current turn progress: { currentTurn, numOfTurns }.
     */
    @GetMapping("/{battleId}/turns")
    public ResponseEntity<TurnProgressResponse> getTurnProgress(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            Integer current = battleService.getCurrentTurn(battleId);
            Integer total   = battleService.getNumOfTurns(battleId);
            return ResponseEntity.ok(new TurnProgressResponse(current, total));
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * POST /guilds/{guildId}/battles/{battleId}/turns/next
     * Advance the battle to the next turn.
     */
    @PostMapping("/{battleId}/turns/next")
    public ResponseEntity<Void> nextTurn(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            battleService.nextTurn(battleId);
            return ResponseEntity.noContent().build();
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * POST /guilds/{guildId}/battles/{battleId}/turns/extend
     * Add one extra turn to the battle (e.g. after a special skill or buff).
     */
    @PostMapping("/{battleId}/turns/extend")
    public ResponseEntity<Void> extendBattle(
            @PathVariable String guildId,
            @PathVariable String battleId) {
        try {
            battleService.increaseNumOfTurn(battleId);
            return ResponseEntity.noContent().build();
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Combat
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * POST /guilds/{guildId}/battles/{battleId}/damage
     * Apply damage dealt by the guild members to the boss this turn.
     * Internally evaluates BattleStatus after damage is applied and fires either BattleWon or BattleLost.
     */
    @PostMapping("/{battleId}/damage")
    public ResponseEntity<Void> dealDamage(
            @PathVariable String guildId,
            @PathVariable String battleId,
            @RequestBody DealDamageRequest request) {
        try {
            battleService.dealDamage(battleId, request.damage());
            return ResponseEntity.noContent().build();
        } catch (BattleNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Request / response records
    // ─────────────────────────────────────────────────────────────────────────

    /** Body for POST /guilds/{guildId}/battles. */
    public record CreateBattleRequest(BossEnemy boss, Integer numOfTurns) {}

    /** Body for POST /guilds/{guildId}/battles/{battleId}/damage. */
    public record DealDamageRequest(Integer damage) {}

    /** Response for GET /guilds/{guildId}/battles/{battleId}/turns. */
    public record TurnProgressResponse(Integer currentTurn, Integer numOfTurns) {}
}