package habitquest.guild.infrastructure;

import common.hexagonal.Adapter;
import habitquest.guild.application.BattleNotifier;
import habitquest.guild.domain.events.battleEvents.BattleLost;
import habitquest.guild.domain.events.battleEvents.BattleStarted;
import habitquest.guild.domain.events.battleEvents.BattleWon;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

/**
 * Outbound adapter that fulfils the BattleNotifier port.
 *
 * notification-service  →  Kafka via Spring Cloud Stream (StreamBridge)
 * avatar-service        →  REST via RestClient
 *
 * Kafka bindings (configure in application.yml):
 *
 *   spring:
 *     cloud:
 *       stream:
 *         bindings:
 *           battle-started-out-0:
 *             destination: battle.started
 *           battle-won-out-0:
 *             destination: battle.won
 *           battle-lost-out-0:
 *             destination: battle.lost
 *         kafka:
 *           binder:
 *             brokers: localhost:9092
 *
 * BattleStarted  [diagram section 1]
 *   → topic battle.started   (avatar-service consumes → snapshots stats/level/mana)
 *
 * BattleWon      [diagram section 4]
 *   → POST avatar-service /avatars/{memberId}/experience/grant  [each member]
 *   → POST avatar-service /avatars/{memberId}/money/earn        [each member]
 *   → topic battle.won  → notification-service: "Battle won!"
 *
 * BattleLost     [diagram section 5]
 *   → POST avatar-service /avatars/{memberId}/health/damage     [each member]
 *   → POST avatar-service /avatars/{memberId}/money/spend       [each member]
 *   → topic battle.lost → notification-service: "Battle lost!"
 */
@Service
@Adapter
public class BattleNotifierImpl implements BattleNotifier {

    private static final String BINDING_BATTLE_STARTED = "battle-started-out-0";
    private static final String BINDING_BATTLE_WON     = "battle-won-out-0";
    private static final String BINDING_BATTLE_LOST    = "battle-lost-out-0";

    private final StreamBridge streamBridge;
    private final RestClient   avatarClient;

    public BattleNotifierImpl(
            StreamBridge streamBridge,
            @Value("${services.avatar.base-url}") String avatarBaseUrl) {
        this.streamBridge = streamBridge;
        this.avatarClient = RestClient.builder().baseUrl(avatarBaseUrl).build();
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BattleStarted  [diagram section 1]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Publishes battle.started to Kafka.
     * avatar-service (and any other interested consumer) reacts by snapshotting
     * each member's stats / level / mana for the duration of the battle.
     *
     * Diagram: «event» BattleStarted(battleId) →
     *   avatar-service.getAvatarStats / getLevel / getMana  [each member]
     */
    @Override
    public void notifyBattleStarted(BattleStarted e) {
        streamBridge.send(BINDING_BATTLE_STARTED, e);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BattleWon  [diagram section 4]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Distributes XP and money rewards to every guild member via REST, then
     * publishes battle.won so notification-service delivers the victory message.
     *
     * Diagram:
     *   «event» BattleWon(battleId, xpReward, moneyReward)
     *   → avatar-service.updateExperience(memberId, xpReward)  [each member]
     *   → avatar-service.updateMoney(memberId, moneyReward)    [each member]
     *   → «async» notification-service.sendNotification(guildId, "Battle won!")
     */
    @Override
    public void notifyBattleWon(BattleWon e) {
        // Fan-out reward calls to every member over REST
        for (String memberId : e.memberIds()) {
            avatarClient.post()
                    .uri("/avatars/{id}/experience/grant", memberId)
                    .body(new AmountRequest(e.experienceReward().amount()))
                    .retrieve()
                    .toBodilessEntity();

            avatarClient.post()
                    .uri("/avatars/{id}/money/earn", memberId)
                    .body(new AmountRequest(e.moneyReward().amount()))
                    .retrieve()
                    .toBodilessEntity();
        }

        // Async notification to the guild via Kafka
        streamBridge.send(
                BINDING_BATTLE_WON,
                new NotificationMessage(
                        e.guildId(),
                        "Battle won!"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // BattleLost  [diagram section 5]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Applies HP and money penalties to every guild member via REST, then
     * publishes battle.lost so notification-service delivers the defeat message.
     *
     * Diagram:
     *   «event» BattleLost(battleId, penalty)
     *   → avatar-service.updateHealth(memberId, -penalty.hp)    [each member]
     *   → avatar-service.updateMoney(memberId, -penalty.money)  [each member]
     *   → «async» notification-service.sendNotification(guildId, "Battle lost!")
     *
     * Note: applyDamage on avatar-service internally fires Dead(health) when
     * HP reaches 0, which avatar-service handles via its own AvatarObserver.
     */
    @Override
    public void notifyBattleLost(BattleLost e) {
        // Fan-out penalty calls to every member over REST
        for (String memberId : e.memberIds()) {
            avatarClient.post()
                    .uri("/avatars/{id}/money/spend", memberId)
                    .body(new AmountRequest(e.penalty().amount()))
                    .retrieve()
                    .toBodilessEntity();
        }

        // Async notification to the guild via Kafka
        streamBridge.send(
                BINDING_BATTLE_LOST,
                new NotificationMessage(
                        e.guildId(),
                        "Battle lost!"));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Payload records
    // ─────────────────────────────────────────────────────────────────────────

    /** REST body for avatar-service amount endpoints (XP, money, HP). */
    private record AmountRequest(Integer amount) {}

    /**
     * Kafka payload consumed by notification-service.
     * recipientId — guild ID that receives the push notification.
     * message     — human-readable text as shown in the diagram.
     */
    private record NotificationMessage(String recipientId, String message) {}
}
