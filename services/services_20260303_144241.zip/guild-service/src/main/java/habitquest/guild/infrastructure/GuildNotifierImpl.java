package habitquest.guild.infrastructure;

import common.hexagonal.Adapter;
import habitquest.guild.application.GuildNotifier;
import habitquest.guild.domain.events.guildEvents.*;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.stereotype.Service;

/**
 * Outbound adapter that fulfils the GuildNotifier port.
 * All guild lifecycle events are published to Kafka via Spring Cloud Stream.
 * notification-service consumes each topic and delivers the push to the member.
 *
 * Kafka bindings (configure in application.yml):
 *
 *   spring:
 *     cloud:
 *       stream:
 *         bindings:
 *           guild-created-out-0:
 *             destination: guild.created
 *           guild-deleted-out-0:
 *             destination: guild.deleted
 *           guild-joined-out-0:
 *             destination: guild.joined
 *           guild-left-out-0:
 *             destination: guild.left
 *           guild-removed-out-0:
 *             destination: guild.removed
 *           guild-role-assigned-out-0:
 *             destination: guild.role-assigned
 *         kafka:
 *           binder:
 *             brokers: localhost:9092
 *
 * Diagram section 6 — notification messages per event:
 *   GuildJoined     → sendNotification(memberId,   "Welcome to the guild!")
 *   GuildLeft       → sendNotification(memberId,   "You left the guild")
 *   RemovedFromGuild→ sendNotification(memberId,   "You have been removed from the guild")
 *   RoleAssigned    → sendNotification(memberId,   "Your role has been updated: <role>")
 *   GuildCreated    → (no diagram notification — published for audit / other consumers)
 *   GuildDeleted    → (no diagram notification — published for audit / other consumers)
 */
@Service
@Adapter
public class GuildNotifierImpl implements GuildNotifier {

    private static final String BINDING_GUILD_CREATED      = "guild-created-out-0";
    private static final String BINDING_GUILD_DELETED      = "guild-deleted-out-0";
    private static final String BINDING_GUILD_JOINED       = "guild-joined-out-0";
    private static final String BINDING_GUILD_LEFT         = "guild-left-out-0";
    private static final String BINDING_GUILD_REMOVED      = "guild-removed-out-0";
    private static final String BINDING_GUILD_ROLE_ASSIGNED = "guild-role-assigned-out-0";

    private final StreamBridge streamBridge;

    public GuildNotifierImpl(StreamBridge streamBridge) {
        this.streamBridge = streamBridge;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Guild lifecycle
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Published when a guild is first created.
     * No notification-service message shown in diagram; published for
     * downstream consumers (analytics, audit, etc.).
     */
    @Override
    public void notifyGuildCreated(GuildCreated e) {
        streamBridge.send(BINDING_GUILD_CREATED, e);
    }

    /**
     * Published when a guild is disbanded.
     * No notification-service message shown in diagram; published for
     * downstream consumers.
     */
    @Override
    public void notifyGuildDeleted(GuildDeleted e) {
        streamBridge.send(BINDING_GUILD_DELETED, e);
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Membership  [diagram section 6]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Diagram: GuildJoined →
     *   notification-service.sendNotification(memberId, "Welcome to the guild!")
     */
    @Override
    public void notifyGuildJoined(GuildJoined e) {
        streamBridge.send(
                BINDING_GUILD_JOINED,
                new NotificationMessage(
                        e.memberId(),
                        "Welcome to the guild!"));
    }

    /**
     * Diagram: GuildLeft →
     *   notification-service.sendNotification(memberId, "You left the guild")
     */
    @Override
    public void notifyGuildLeft(GuildLeft e) {
        streamBridge.send(
                BINDING_GUILD_LEFT,
                new NotificationMessage(
                        e.memberId(),
                        "You left the guild"));
    }

    /**
     * A member was removed by an officer / leader.
     * Diagram shows no explicit arrow for this event (it is distinct from
     * GuildLeft), but the notification pattern is consistent with section 6.
     */
    @Override
    public void notifyRemovedFromGuild(RemovedFromGuild e) {
        streamBridge.send(
                BINDING_GUILD_REMOVED,
                new NotificationMessage(
                        e.memberId(),
                        "You have been removed from the guild"));
    }

    /**
     * A member's role was promoted / updated.
     * Diagram: RankUpdated / RoleAssigned →
     *   notification-service.sendNotification(guildId, "Rank updated: #" + rank)
     */
    @Override
    public void notifyRoleAssigned(RoleAssigned e) {
        streamBridge.send(
                BINDING_GUILD_ROLE_ASSIGNED,
                new NotificationMessage(
                        e.memberId(),
                        "Your role has been updated: " + e.newRole()));
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Payload record
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Kafka payload consumed by notification-service.
     * recipientId — avatar / guild ID that receives the push notification.
     * message     — human-readable text as shown in the diagram.
     */
    private record NotificationMessage(String recipientId, String message) {}
}