package habitquest.guild.domain.events.battleEvents;

import habitquest.guild.domain.battle.Penalty;

import java.util.List;

public record BattleLost(String battleId, String guildId, Penalty penalty, List<String> memberIds) implements BattleEvent {}
