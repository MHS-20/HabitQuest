package habitquest.guild.domain.events.battleEvents;

import habitquest.guild.domain.battle.Experience;
import habitquest.guild.domain.battle.Money;

import java.util.List;

public record BattleWon(String battleId, String guildId, Experience experienceReward, Money moneyReward, List<String> memberIds)
    implements BattleEvent {}
