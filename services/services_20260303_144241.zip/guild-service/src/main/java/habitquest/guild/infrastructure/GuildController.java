package habitquest.guild.infrastructure;

import habitquest.guild.application.GuildService;
import habitquest.guild.application.GuildNotFoundException;
import habitquest.guild.domain.guild.Guild;
import habitquest.guild.domain.guild.GuildMember;
import habitquest.guild.domain.guild.GuildRole;
import java.util.List;
import java.util.Optional;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Base path: /guilds
 */
@RestController
@RequestMapping("/guilds")
public class GuildController {

    private final GuildService guildService;

    public GuildController(GuildService guildService) {
        this.guildService = guildService;
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Guild CRUD
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * POST /guilds
     * Create a new guild.
     * Internally fires GuildCreated event (observed by notification-service).
     * Returns 201 Created with the generated guild ID.
     */
    @PostMapping
    public ResponseEntity<String> createGuild(@RequestBody CreateGuildRequest request) {
        String id = guildService.createGuild(
                request.name(),
                request.creatorAvatarId(),
                request.creatorNickname());
        return ResponseEntity.status(HttpStatus.CREATED).body(id);
    }

    /**
     * GET /guilds
     * Retrieve all guilds sorted by global rank (leaderboard).
     */
    @GetMapping
    public ResponseEntity<List<Guild>> getLeaderboard() {
        return ResponseEntity.ok(guildService.getGuildLeaderboard());
    }

    /**
     * GET /guilds/{guildId}
     * Retrieve a single guild by ID.
     */
    @GetMapping("/{guildId}")
    public ResponseEntity<Guild> getGuild(@PathVariable String guildId) {
        try {
            Optional<Guild> guild = guildService.getGuild(guildId);
            return guild.map(ResponseEntity::ok)
                    .orElse(ResponseEntity.notFound().build());
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * PUT /guilds/{guildId}
     * Update guild data (e.g. global rank after a leaderboard recalculation).
     * Internally: persists new rank, which can trigger RankUpdated
     **/
    @PutMapping("/{guildId}")
    public ResponseEntity<Void> updateGuild(
            @PathVariable String guildId,
            @RequestBody Guild request) {
        try {
            guildService.updateGuild(guildId, request);
            return ResponseEntity.noContent().build();
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * DELETE /guilds/{guildId}
     * Disband a guild.
     * Internally fires GuildDeleted event.
     */
    @DeleteMapping("/{guildId}")
    public ResponseEntity<Void> deleteGuild(@PathVariable String guildId) {
        try {
            guildService.deleteGuild(guildId);
            return ResponseEntity.noContent().build();
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Ranking
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * GET /guilds/{guildId}/rank
     * Retrieve the current global rank of a guild.
     */
    @GetMapping("/{guildId}/rank")
    public ResponseEntity<Integer> getGlobalRank(@PathVariable String guildId) {
        try {
            return ResponseEntity.ok(guildService.getGlobalRank(guildId));
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Membership management  [diagram section 6]
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * GET /guilds/{guildId}/members
     * List all members of a guild.
     */
    @GetMapping("/{guildId}/members")
    public ResponseEntity<List<GuildMember>> getMembers(@PathVariable String guildId) {
        try {
            return ResponseEntity.ok(guildService.getMembers(guildId));
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * POST /guilds/{guildId}/members
     * A player joins (or is accepted into) the guild.
     * Internally fires GuildJoined
     */
    @PostMapping("/{guildId}/members")
    public ResponseEntity<Void> addMember(
            @PathVariable String guildId,
            @RequestBody GuildMember member) {
        try {
            guildService.addMember(guildId, member);
            return ResponseEntity.status(HttpStatus.CREATED).build();
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * DELETE /guilds/{guildId}/members/{memberId}
     * A member voluntarily leaves the guild.
     * Internally fires GuildLeft
     */
    @DeleteMapping("/{guildId}/members/{memberId}")
    public ResponseEntity<Void> leaveGuild(
            @PathVariable String guildId,
            @PathVariable String memberId) {
        try {
            guildService.leaveGuild(guildId, memberId);
            return ResponseEntity.noContent().build();
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * DELETE /guilds/{guildId}/members/{memberId}/kick
     * An officer/leader removes a member from the guild.
     * Internally fires RemovedFromGuild event (distinct from a voluntary leave).
     *
     * A dedicated sub-path /kick distinguishes an admin removal from a self-leave
     * on the same member resource, keeping DELETE /members/{memberId} unambiguous.
     */
    @DeleteMapping("/{guildId}/members/{memberId}/kick")
    public ResponseEntity<Void> removeMember(
            @PathVariable String guildId,
            @PathVariable String memberId) {
        try {
            guildService.removeMember(guildId, memberId);
            return ResponseEntity.noContent().build();
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * PATCH /guilds/{guildId}/members/{memberId}/role
     * Promote (or demote) a member to a new role.
     * Internally fires RoleAssigned event.
     *
     * [diagram section 6 — InviteSent context: rank/role changes within the guild]
     */
    @PatchMapping("/{guildId}/members/{memberId}/role")
    public ResponseEntity<Void> promoteMember(
            @PathVariable String guildId,
            @PathVariable String memberId,
            @RequestBody PromoteMemberRequest request) {
        try {
            guildService.promoteMember(guildId, memberId, request.newRole());
            return ResponseEntity.noContent().build();
        } catch (GuildNotFoundException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // ─────────────────────────────────────────────────────────────────────────
    // Request / response records
    // ─────────────────────────────────────────────────────────────────────────

    /**
     * Body for POST /guilds.
     * creatorNickname is the display name the founder wants inside the guild.
     */
    public record CreateGuildRequest(
            String name,
            String creatorAvatarId,
            String creatorNickname) {}

    /** Body for PATCH /guilds/{guildId}/members/{memberId}/role. */
    public record PromoteMemberRequest(GuildRole newRole) {}
}