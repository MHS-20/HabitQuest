package habitquest.edge.application;

import common.ddd.DomainService;
import common.hexagonal.InBoundPort;
import habitquest.edge.domain.User;
import habitquest.edge.domain.UserExceptions.InvalidCredentialsException;
import habitquest.edge.domain.UserExceptions.UserAlreadyExistsException;
import habitquest.edge.domain.UserExceptions.UserNotFoundException;
import habitquest.edge.domain.UserFactory;
import habitquest.edge.infrastructure.JwtService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@InBoundPort
@Service
public class AuthService implements DomainService {

  private final UserRepository userRepository;
  private final JwtService jwtService;
  private final PasswordEncoder passwordEncoder;
  private final UserFactory userFactory;

  public AuthService(
      UserRepository userRepository,
      JwtService jwtService,
      PasswordEncoder passwordEncoder,
      UserFactory userFactory) {
    this.userRepository = userRepository;
    this.jwtService = jwtService;
    this.passwordEncoder = passwordEncoder;
    this.userFactory = userFactory;
  }

  public AuthResponse register(String email, String rawPassword) {
    if (userRepository.existsByEmail(email)) {
      throw new UserAlreadyExistsException(email);
    }

    String hash = passwordEncoder.encode(rawPassword);
    User user = userRepository.save(userFactory.create(email, hash));
    return new AuthResponse(jwtService.generateToken(user), user.getId());
  }

  public AuthResponse login(String email, String rawPassword) {
    User user =
        userRepository.findByEmail(email).orElseThrow(() -> new UserNotFoundException(email));
    if (!passwordEncoder.matches(rawPassword, user.getPasswordHash())) {
      throw new InvalidCredentialsException();
    }
    return new AuthResponse(jwtService.generateToken(user), user.getId());
  }

  public boolean validateToken(String token) {
    return jwtService.isValid(token);
  }

  // ── response DTO ──────────────────────────────────────────────────────────
  public record AuthResponse(String token, String userId) {}
}
