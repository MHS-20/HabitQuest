package habitquest.edge;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.github.tomakehurst.wiremock.client.WireMock;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

class RegistrationControllerTest extends EdgeServiceTestBase {

  @BeforeEach
  void resetMocks() {
    avatarServiceMock.resetAll();
  }

  @Test
  void register_shouldReturn201_whenBothKeycloakAndAvatarSucceed() throws Exception {
    // Stub avatar service
    avatarServiceMock.stubFor(
        WireMock.post(urlEqualTo("/api/v1/avatars"))
            .willReturn(
                aResponse()
                    .withStatus(201)
                    .withHeader("Content-Type", "application/json")
                    .withBody(
                        """
                                {"id": "avatar-new-123"}
                                """)));

    mockMvc
        .perform(
            post("/api/v1/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    """
                                {
                                  "username": "newuser",
                                  "email": "new@habitquest.com",
                                  "password": "secret123",
                                  "nickname": "NewHero"
                                }
                                """))
        .andExpect(status().isCreated());
  }

  @Test
  void register_shouldReturn503_whenAvatarServiceIsDown() throws Exception {
    // Avatar service non risponde
    avatarServiceMock.stubFor(
        WireMock.post(urlEqualTo("/api/v1/avatars")).willReturn(aResponse().withStatus(500)));

    mockMvc
        .perform(
            post("/api/v1/auth/register")
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    """
                                {
                                  "username": "newuser2",
                                  "email": "new2@habitquest.com",
                                  "password": "secret123",
                                  "nickname": "NewHero2"
                                }
                                """))
        .andExpect(status().isServiceUnavailable());
  }

  @Test
  void register_shouldReturn409_whenUserAlreadyExistsOnKeycloak() throws Exception {
    // Registra prima l'utente
    avatarServiceMock.stubFor(
        WireMock.post(urlEqualTo("/api/v1/avatars"))
            .willReturn(
                aResponse()
                    .withStatus(201)
                    .withHeader("Content-Type", "application/json")
                    .withBody(
                        """
                                {"id": "avatar-dup-123"}
                                """)));

    String body =
        """
                {
                  "username": "duplicateuser",
                  "email": "dup@habitquest.com",
                  "password": "secret123",
                  "nickname": "DupHero"
                }
                """;

    mockMvc
        .perform(
            post("/api/v1/auth/register").contentType(MediaType.APPLICATION_JSON).content(body))
        .andExpect(status().isCreated());

    // Seconda registrazione con stesso username → 409
    mockMvc
        .perform(
            post("/api/v1/auth/register").contentType(MediaType.APPLICATION_JSON).content(body))
        .andExpect(status().isConflict());
  }
}
