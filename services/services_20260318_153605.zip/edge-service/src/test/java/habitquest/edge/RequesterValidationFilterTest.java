package habitquest.edge;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.http.MediaType;

class RequesterValidationFilterTest extends EdgeServiceTestBase {

  @Test
  void request_shouldReturn403_whenRequesterIdDoesNotMatchJwt() throws Exception {
    String token = getToken("testuser", "password"); // avatar_id = "avatar-123"

    mockMvc
        .perform(
            post("/api/v1/guilds/guild-1/invites")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    """
                                {
                                  "requestorId": "avatar-DIFFERENT",
                                  "targetAvatarId": "avatar-456"
                                }
                                """))
        .andExpect(status().isForbidden());
  }

  @Test
  void request_shouldProceed_whenRequesterIdMatchesJwt() throws Exception {
    String token = getToken("testuser", "password"); // avatar_id = "avatar-123"

    guildServiceMock.stubFor(
        com.github.tomakehurst.wiremock.client.WireMock.post(
                urlEqualTo("/api/v1/guilds/guild-1/invites"))
            .willReturn(aResponse().withStatus(204)));

    mockMvc
        .perform(
            post("/api/v1/guilds/guild-1/invites")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON)
                .content(
                    """
                                {
                                  "requestorId": "avatar-123",
                                  "targetAvatarId": "avatar-456"
                                }
                                """))
        .andExpect(status().isNoContent());
  }

  @Test
  void request_shouldProceed_whenNoRequesterFieldInBody() throws Exception {
    String token = getToken("testuser", "password");

    guildServiceMock.stubFor(
        com.github.tomakehurst.wiremock.client.WireMock.post(
                urlEqualTo("/api/v1/guilds/guild-1/members/avatar-456/leave"))
            .willReturn(aResponse().withStatus(204)));

    // leaveGuild non ha requestorId nel body, deve passare liberamente
    mockMvc
        .perform(
            post("/api/v1/guilds/guild-1/members/avatar-456/leave")
                .header("Authorization", "Bearer " + token)
                .contentType(MediaType.APPLICATION_JSON))
        .andExpect(status().isNoContent());
  }
}
