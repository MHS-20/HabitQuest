package habitquest.edge;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;

class JwtValidationTest extends EdgeServiceTestBase {

  @Test
  void request_shouldReturn401_whenNoToken() throws Exception {
    mockMvc.perform(get("/api/v1/avatars/avatar-123")).andExpect(status().isUnauthorized());
  }

  @Test
  void request_shouldReturn401_whenTokenIsMalformed() throws Exception {
    mockMvc
        .perform(
            get("/api/v1/avatars/avatar-123").header("Authorization", "Bearer not.a.valid.jwt"))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void request_shouldReturn401_whenTokenIsExpired() throws Exception {
    // Token firmato ma con exp nel passato
    String expiredToken = "eyJhbGciOiJSUzI1NiJ9.eyJzdWIiOiJ1c2VyIiwiZXhwIjoxfQ.invalidsig";
    mockMvc
        .perform(
            get("/api/v1/avatars/avatar-123").header("Authorization", "Bearer " + expiredToken))
        .andExpect(status().isUnauthorized());
  }

  @Test
  void request_shouldProceed_whenTokenIsValid() throws Exception {
    avatarServiceMock.stubFor(
        com.github.tomakehurst.wiremock.client.WireMock.get(
                urlEqualTo("/api/v1/avatars/avatar-123"))
            .willReturn(
                aResponse()
                    .withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBody(
                        """
                                {"id":"avatar-123"}""")));

    String token = getToken("testuser", "password");

    mockMvc
        .perform(get("/api/v1/avatars/avatar-123").header("Authorization", "Bearer " + token))
        .andExpect(status().isOk());
  }
}
