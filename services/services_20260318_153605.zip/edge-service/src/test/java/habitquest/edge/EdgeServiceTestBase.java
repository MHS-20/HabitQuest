package habitquest.edge;

import static io.restassured.RestAssured.given;

import com.github.tomakehurst.wiremock.WireMockServer;
import com.github.tomakehurst.wiremock.core.WireMockConfiguration;
import dasniko.testcontainers.keycloak.KeycloakContainer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.springframework.test.web.servlet.MockMvc;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
@Testcontainers
@ActiveProfiles("test")
public abstract class EdgeServiceTestBase {

  // ─── Keycloak ─────────────────────────────────────────────────────────────
  @Container
  static final KeycloakContainer keycloak =
      new KeycloakContainer("quay.io/keycloak/keycloak:26.0")
          .withRealmImportFile("keycloak/habitquest-realm.json")
          .withReuse(true);

  static final WireMockServer avatarServiceMock;
  static final WireMockServer guildServiceMock;
  static final WireMockServer questServiceMock;
  static final WireMockServer trackingServiceMock;

  static {
    avatarServiceMock = new WireMockServer(WireMockConfiguration.options().port(8081));
    guildServiceMock = new WireMockServer(WireMockConfiguration.options().port(8082));
    questServiceMock = new WireMockServer(WireMockConfiguration.options().port(8083));
    trackingServiceMock = new WireMockServer(WireMockConfiguration.options().port(8084));

    keycloak.start();
    avatarServiceMock.start();
    guildServiceMock.start();
    questServiceMock.start();
    trackingServiceMock.start();

    Runtime.getRuntime()
        .addShutdownHook(
            new Thread(
                () -> {
                  avatarServiceMock.stop();
                  guildServiceMock.stop();
                  questServiceMock.stop();
                  trackingServiceMock.stop();
                }));
  }

  @Autowired protected MockMvc mockMvc;

  @DynamicPropertySource
  static void overrideProperties(DynamicPropertyRegistry registry) {
    registry.add(
        "spring.security.oauth2.resourceserver.jwt.issuer-uri",
        () -> keycloak.getAuthServerUrl() + "/realms/habitquest");
    registry.add(
        "keycloak.admin.uri", () -> keycloak.getAuthServerUrl() + "/admin/realms/habitquest");
    registry.add(
        "keycloak.master.token-uri",
        () -> keycloak.getAuthServerUrl() + "/realms/master/protocol/openid-connect/token");
    registry.add("services.avatar.base-url", () -> "http://localhost:8081");
  }

  protected String getToken(String username, String password) {
    return given()
        .contentType("application/x-www-form-urlencoded")
        .formParam("grant_type", "password")
        .formParam("client_id", "edge-service")
        .formParam("client_secret", "habitquest-keycloak-secret")
        .formParam("username", username)
        .formParam("password", password)
        .post(keycloak.getAuthServerUrl() + "/realms/habitquest/protocol/openid-connect/token")
        .jsonPath()
        .getString("access_token");
  }
}
