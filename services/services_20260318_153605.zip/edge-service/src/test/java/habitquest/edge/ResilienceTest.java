package habitquest.edge;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

class ResilienceTest extends EdgeServiceTestBase {

  @Test
  void circuitBreaker_shouldReturn503_whenServiceIsDown() throws Exception {
    avatarServiceMock.stubFor(
        get(urlPathMatching("/api/v1/avatars/.*")).willReturn(aResponse().withStatus(500)));

    String token = getToken("testuser", "password");

    for (int i = 0; i < 20; i++) {
      mockMvc.perform(
          MockMvcRequestBuilders.get("/api/v1/avatars/avatar-123")
              .header("Authorization", "Bearer " + token));
    }

    mockMvc
        .perform(
            MockMvcRequestBuilders.get("/api/v1/avatars/avatar-123")
                .header("Authorization", "Bearer " + token))
        .andExpect(status().isServiceUnavailable());

    avatarServiceMock.verify(exactly(20), getRequestedFor(urlPathMatching("/api/v1/avatars/.*")));
  }

  @Test
  void rateLimiter_shouldReturn429_whenLimitExceeded() throws Exception {
    avatarServiceMock.stubFor(
        get(urlPathMatching("/api/v1/avatars/.*"))
            .willReturn(
                aResponse()
                    .withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBody(
                        """
                                {"id":"avatar-123"}""")));

    String token = getToken("testuser", "password");

    for (int i = 0; i < 10; i++) {
      mockMvc
          .perform(
              MockMvcRequestBuilders.get("/api/v1/avatars/avatar-123")
                  .header("Authorization", "Bearer " + token))
          .andExpect(status().isOk());
    }

    mockMvc
        .perform(
            MockMvcRequestBuilders.get("/api/v1/avatars/avatar-123")
                .header("Authorization", "Bearer " + token))
        .andExpect(status().isTooManyRequests());
  }
}
