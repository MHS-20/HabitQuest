package habitquest.edge;

import static com.github.tomakehurst.wiremock.client.WireMock.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Test;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

class RoutingTest extends EdgeServiceTestBase {

  @Test
  void avatarRoute_shouldForwardToAvatarService() throws Exception {
    avatarServiceMock.stubFor(
        get(urlEqualTo("/api/v1/avatars/avatar-123"))
            .willReturn(
                aResponse()
                    .withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBody(
                        """
                                {"id":"avatar-123"}""")));

    String token = getToken("testuser", "password");

    mockMvc
        .perform(
            MockMvcRequestBuilders.get("/api/v1/avatars/avatar-123")
                .header("Authorization", "Bearer " + token))
        .andExpect(status().isOk());

    avatarServiceMock.verify(getRequestedFor(urlEqualTo("/api/v1/avatars/avatar-123")));
  }

  @Test
  void guildRoute_shouldForwardToGuildService() throws Exception {
    guildServiceMock.stubFor(
        get(urlEqualTo("/api/v1/guilds/guild-1"))
            .willReturn(
                aResponse()
                    .withStatus(200)
                    .withHeader("Content-Type", "application/json")
                    .withBody(
                        """
                                {"id":"guild-1"}""")));

    String token = getToken("testuser", "password");

    mockMvc
        .perform(
            MockMvcRequestBuilders.get("/api/v1/guilds/guild-1")
                .header("Authorization", "Bearer " + token))
        .andExpect(status().isOk());

    guildServiceMock.verify(getRequestedFor(urlEqualTo("/api/v1/guilds/guild-1")));
  }

  @Test
  void unknownRoute_shouldReturn404() throws Exception {
    String token = getToken("testuser", "password");

    mockMvc
        .perform(
            MockMvcRequestBuilders.get("/api/v1/unknown/resource")
                .header("Authorization", "Bearer " + token))
        .andExpect(status().isNotFound());
  }
}
