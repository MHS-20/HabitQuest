package habitquest.edge;

import io.github.resilience4j.circuitbreaker.CallNotPermittedException;
import io.github.resilience4j.circuitbreaker.CircuitBreaker;
import io.github.resilience4j.circuitbreaker.CircuitBreakerRegistry;
import io.github.resilience4j.ratelimiter.RateLimiter;
import io.github.resilience4j.ratelimiter.RateLimiterRegistry;
import io.github.resilience4j.ratelimiter.RequestNotPermitted;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

@Component
@Order(2)
public class ResilienceFilter implements Filter {

  private final CircuitBreakerRegistry circuitBreakerRegistry;
  private final RateLimiterRegistry rateLimiterRegistry;

  public ResilienceFilter(
      CircuitBreakerRegistry circuitBreakerRegistry, RateLimiterRegistry rateLimiterRegistry) {
    this.circuitBreakerRegistry = circuitBreakerRegistry;
    this.rateLimiterRegistry = rateLimiterRegistry;
  }

  @Override
  public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
      throws IOException, ServletException {

    HttpServletRequest httpReq = (HttpServletRequest) req;
    String serviceName = resolveServiceName(httpReq.getRequestURI());

    RateLimiter rateLimiter = rateLimiterRegistry.rateLimiter("default");
    CircuitBreaker circuitBreaker = circuitBreakerRegistry.circuitBreaker(serviceName);

    try {
      RateLimiter.decorateCheckedRunnable(
              rateLimiter,
              CircuitBreaker.decorateCheckedRunnable(
                  circuitBreaker, () -> chain.doFilter(req, res)))
          .run();

    } catch (RequestNotPermitted e) {
      ((HttpServletResponse) res).setStatus(HttpStatus.TOO_MANY_REQUESTS.value());
    } catch (CallNotPermittedException e) {
      ((HttpServletResponse) res).setStatus(HttpStatus.SERVICE_UNAVAILABLE.value());
    } catch (IOException | ServletException e) {
      throw e;
    } catch (Throwable e) {
      if (e.getCause() instanceof RuntimeException re) throw re;
      if (e instanceof RuntimeException re) throw re;
      ((HttpServletResponse) res).setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
    }
  }

  private String resolveServiceName(String uri) {
    if (uri.startsWith("/api/v1/avatars")) return "avatar-service";
    if (uri.startsWith("/api/v1/guilds")) return "guild-service";
    if (uri.startsWith("/api/v1/battles")) return "guild-service";
    return "default";
  }
}
