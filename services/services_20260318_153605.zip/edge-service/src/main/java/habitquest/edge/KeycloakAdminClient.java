package habitquest.edge;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestClient;

@Component
public class KeycloakAdminClient {

  private final RestClient restClient;
  private final String adminUri;
  private final String masterTokenUri;

  public KeycloakAdminClient(
      RestClient.Builder builder,
      @Value("${keycloak.admin.uri}") String adminUri,
      @Value("${keycloak.master.token-uri}") String masterTokenUri) {
    this.restClient = builder.build();
    this.adminUri = adminUri;
    this.masterTokenUri = masterTokenUri;
  }

  private String getAdminToken() {
    @SuppressWarnings("unchecked")
    Map<String, Object> response =
        restClient
            .post()
            .uri(masterTokenUri)
            .contentType(MediaType.APPLICATION_FORM_URLENCODED)
            .body("grant_type=password&client_id=admin-cli&username=admin&password=admin")
            .retrieve()
            .body(Map.class);

    return (String) response.get("access_token");
  }

  public String createUser(RegistrationController.RegisterRequest req) {
    Map<String, Object> body =
        Map.of(
            "username", req.username(),
            "email", req.email(),
            "enabled", true,
            "credentials",
                List.of(Map.of("type", "password", "value", req.password(), "temporary", false)));

    try {
      ResponseEntity<Void> response =
          restClient
              .post()
              .uri(adminUri + "/users")
              .header("Authorization", "Bearer " + getAdminToken())
              .contentType(MediaType.APPLICATION_JSON)
              .body(body)
              .retrieve()
              .toBodilessEntity();

      String location = response.getHeaders().getFirst("Location");
      return location.substring(location.lastIndexOf('/') + 1);

    } catch (HttpClientErrorException.Conflict e) {
      throw new KeycloakUserAlreadyExistsException("User already exists: " + req.username());
    } catch (HttpClientErrorException e) {
      throw new KeycloakUserAlreadyExistsException("Keycloak error (4xx): " + e.getMessage());
    }
  }
}
