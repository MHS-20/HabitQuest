package habitquest.edge;

public class AvatarCreationException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public AvatarCreationException(String message) {
    super(message);
  }
}
