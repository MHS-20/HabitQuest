package habitquest.edge;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClient;

@Component
public class AvatarClient {

  private static final Logger LOG = LoggerFactory.getLogger(AvatarClient.class);

  private final RestClient restClient;

  public AvatarClient(
      RestClient.Builder builder, @Value("${services.avatar.base-url}") String baseUrl) {
    this.restClient = builder.baseUrl(baseUrl).build();
  }

  public String createAvatar(String name) {
    try {
      AvatarCreatedResponse response =
          restClient
              .post()
              .uri("/api/v1/avatars")
              .body(new CreateAvatarRequest(name))
              .retrieve()
              .body(AvatarCreatedResponse.class);

      LOG.info("Avatar created with id={}", response.id());
      return response.id();

    } catch (HttpClientErrorException e) {
      throw new AvatarCreationException("Avatar creation failed (4xx): " + e.getMessage());
    } catch (HttpServerErrorException e) {
      throw new AvatarCreationException("Avatar service unavailable (5xx)");
    }
  }

  private record CreateAvatarRequest(String name) {}

  private record AvatarCreatedResponse(String id) {}
}
