package habitquest.edge;

public class KeycloakUserAlreadyExistsException extends RuntimeException {
  private static final long serialVersionUID = 1L;

  public KeycloakUserAlreadyExistsException(String message) {
    super(message);
  }
}
