package habitquest.edge;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/auth")
public class RegistrationController {

  private final KeycloakAdminClient keycloakAdmin;
  private final AvatarClient avatarClient;

  public RegistrationController(KeycloakAdminClient keycloakAdmin, AvatarClient avatarClient) {
    this.keycloakAdmin = keycloakAdmin;
    this.avatarClient = avatarClient;
  }

  @PostMapping("/register")
  public ResponseEntity<Void> register(@RequestBody RegisterRequest request) {
    try {
      keycloakAdmin.createUser(request);
      avatarClient.createAvatar(request.nickname());
      return ResponseEntity.<Void>status(HttpStatus.CREATED).build();

    } catch (KeycloakUserAlreadyExistsException e) {
      return ResponseEntity.<Void>status(HttpStatus.CONFLICT).build();

    } catch (AvatarCreationException e) {
      return ResponseEntity.<Void>status(HttpStatus.SERVICE_UNAVAILABLE).build();
    }
  }

  public record RegisterRequest(String username, String email, String password, String nickname) {}
}
