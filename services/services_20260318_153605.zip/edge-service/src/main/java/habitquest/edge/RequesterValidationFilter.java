package habitquest.edge;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ReadListener;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletInputStream;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletRequestWrapper;
import jakarta.servlet.http.HttpServletResponse;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Component;

@Component
@Order(1)
public class RequesterValidationFilter implements Filter {

  private static final String[] REQUESTER_FIELDS = {
    "requesterId", "requestorId", "attackerAvatarId"
  };

  private final ObjectMapper objectMapper;

  public RequesterValidationFilter(ObjectMapper objectMapper) {
    this.objectMapper = objectMapper;
  }

  @Override
  public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
      throws IOException, ServletException {

    HttpServletRequest httpReq = (HttpServletRequest) req;
    HttpServletResponse httpRes = (HttpServletResponse) res;

    // Solo le richieste con body
    if (HttpMethod.GET.matches(httpReq.getMethod())) {
      chain.doFilter(req, res);
      return;
    }

    // Leggi e bufferizza il body (può essere letto una sola volta)
    byte[] bodyBytes = httpReq.getInputStream().readAllBytes();

    // Estrai avatarId dal JWT
    var authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication == null || !(authentication.getPrincipal() instanceof Jwt jwt)) {
      chain.doFilter(new CachedBodyRequestWrapper(httpReq, bodyBytes), res);
      return;
    }

    String avatarIdFromJwt = jwt.getClaimAsString("avatar_id");

    // Cerca uno dei campi requester nel body
    if (bodyBytes.length > 0) {
      try {
        JsonNode body = objectMapper.readTree(bodyBytes);

        for (String field : REQUESTER_FIELDS) {
          JsonNode node = body.get(field);
          if (node != null && !node.isNull()) {
            String requesterIdFromBody = node.asText();
            if (!avatarIdFromJwt.equals(requesterIdFromBody)) {
              httpRes.setStatus(HttpStatus.FORBIDDEN.value());
              return;
            }
            break; // trovato e validato
          }
        }

      } catch (IOException e) {
        httpRes.setStatus(HttpStatus.BAD_REQUEST.value());
        return;
      }
    }

    // Passa il body bufferizzato al downstream (altrimenti risulta già consumato)
    chain.doFilter(new CachedBodyRequestWrapper(httpReq, bodyBytes), res);
  }

  // ─── Wrapper per permettere la rilettura del body ────────────────────────
  private static class CachedBodyRequestWrapper extends HttpServletRequestWrapper {

    private final byte[] cachedBody;

    public CachedBodyRequestWrapper(HttpServletRequest request, byte[] cachedBody) {
      super(request);
      this.cachedBody = cachedBody;
    }

    @Override
    public ServletInputStream getInputStream() {
      ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(cachedBody);
      return new ServletInputStream() {
        @Override
        public int read() {
          return byteArrayInputStream.read();
        }

        @Override
        public boolean isFinished() {
          return byteArrayInputStream.available() == 0;
        }

        @Override
        public boolean isReady() {
          return true;
        }

        @Override
        public void setReadListener(ReadListener listener) {}
      };
    }
  }
}
