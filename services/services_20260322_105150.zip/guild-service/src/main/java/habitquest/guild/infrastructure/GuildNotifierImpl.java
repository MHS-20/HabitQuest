package habitquest.guild.infrastructure;

import common.hexagonal.Adapter;
import habitquest.guild.application.GuildNotifier;
import habitquest.guild.domain.events.guildEvents.*;
import java.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.stereotype.Component;

@Adapter
@Component
public class GuildNotifierImpl implements GuildNotifier {

  private static final Logger LOG = LoggerFactory.getLogger(GuildNotifierImpl.class);

  static final String GUILD_CREATED_BINDING = "guild.created";
  static final String GUILD_DELETED_BINDING = "guild.deleted";
  static final String GUILD_JOINED_BINDING = "guild.joined";
  static final String GUILD_LEFT_BINDING = "guild.left";
  static final String REMOVED_FROM_GUILD_BINDING = "guild.removed";
  static final String ROLE_ASSIGNED_BINDING = "guild.role-assigned";
  static final String INVITE_SENT_BINDING = "guild.invite-sent";

  private final StreamBridge streamBridge;

  public GuildNotifierImpl(StreamBridge streamBridge) {
    this.streamBridge = streamBridge;
  }

  @Override
  public void notifyGuildCreated(GuildCreated event) {
    GuildCreatedMessage message =
        new GuildCreatedMessage(event.guildId().value(), event.guildName(), Instant.now());

    LOG.info(
        "Publishing GuildCreated event: guildId={}, name={}", message.guildId(), message.name());
    boolean sent = streamBridge.send(GUILD_CREATED_BINDING, message);
    if (!sent) {
      LOG.error("Failed to publish GuildCreated event for guildId {}", message.guildId());
    }
  }

  @Override
  public void notifyGuildDeleted(GuildDeleted event) {
    GuildDeletedMessage message = new GuildDeletedMessage(event.guildId().value(), Instant.now());

    LOG.info("Publishing GuildDeleted event: guildId={}", message.guildId());
    boolean sent = streamBridge.send(GUILD_DELETED_BINDING, message);
    if (!sent) {
      LOG.error("Failed to publish GuildDeleted event for guildId {}", message.guildId());
    }
  }

  @Override
  public void notifyInviteSent(InviteSent event) {
    var message =
        new InviteSentMessage(
            event.guildId().value(), event.targetAvatarId().value(), event.inviteId().value(), Instant.now());
    streamBridge.send(INVITE_SENT_BINDING, message);
  }

  public record InviteSentMessage(
      String guildId, String targetAvatarId, String inviteId, Instant occurredOn) {}

  @Override
  public void notifyGuildJoined(GuildJoined event) {
    GuildJoinedMessage message =
        new GuildJoinedMessage(event.guildId().value(), event.memberId().value(), Instant.now());

    LOG.info(
        "Publishing GuildJoined event: guildId={}, memberId={}",
        message.guildId(),
        message.memberId());
    boolean sent = streamBridge.send(GUILD_JOINED_BINDING, message);
    if (!sent) {
      LOG.error("Failed to publish GuildJoined event for guildId {}", message.guildId());
    }
  }

  @Override
  public void notifyGuildLeft(GuildLeft event) {
    GuildLeftMessage message =
        new GuildLeftMessage(event.guildId().value(), event.memberId().value(), Instant.now());

    LOG.info(
        "Publishing GuildLeft event: guildId={}, memberId={}",
        message.guildId(),
        message.memberId());
    boolean sent = streamBridge.send(GUILD_LEFT_BINDING, message);
    if (!sent) {
      LOG.error("Failed to publish GuildLeft event for guildId {}", message.guildId());
    }
  }

  @Override
  public void notifyRemovedFromGuild(RemovedFromGuild event) {
    RemovedFromGuildMessage message =
        new RemovedFromGuildMessage(event.guildId().value(), event.memberId().value(), Instant.now());

    LOG.info(
        "Publishing RemovedFromGuild event: guildId={}, memberId={}",
        message.guildId(),
        message.memberId());
    boolean sent = streamBridge.send(REMOVED_FROM_GUILD_BINDING, message);
    if (!sent) {
      LOG.error("Failed to publish RemovedFromGuild event for guildId {}", message.guildId());
    }
  }

  @Override
  public void notifyRoleAssigned(RoleAssigned event) {
    RoleAssignedMessage message =
        new RoleAssignedMessage(
            event.guildId().value(), event.memberId().value(), event.newRole().name(), Instant.now());

    LOG.info(
        "Publishing RoleAssigned event: guildId={}, memberId={}, role={}",
        message.guildId(),
        message.memberId(),
        message.roleName);
    boolean sent = streamBridge.send(ROLE_ASSIGNED_BINDING, message);
    if (!sent) {
      LOG.error("Failed to publish RoleAssigned event for guildId {}", message.guildId());
    }
  }

  public record GuildCreatedMessage(String guildId, String name, Instant occurredOn) {}

  public record GuildDeletedMessage(String guildId, Instant occurredOn) {}

  public record GuildJoinedMessage(String guildId, String memberId, Instant occurredOn) {}

  public record GuildLeftMessage(String guildId, String memberId, Instant occurredOn) {}

  public record RemovedFromGuildMessage(String guildId, String memberId, Instant occurredOn) {}

  public record RoleAssignedMessage(
      String guildId, String memberId, String roleName, Instant occurredOn) {}
}
