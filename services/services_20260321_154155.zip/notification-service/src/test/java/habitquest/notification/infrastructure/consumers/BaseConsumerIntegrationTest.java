package habitquest.notification.infrastructure.consumers;

import static org.assertj.core.api.Assertions.assertThat;

import com.icegreen.greenmail.util.GreenMail;
import com.icegreen.greenmail.util.ServerSetup;
import habitquest.notification.infrastructure.repository.GuildMemberRepository;
import habitquest.notification.infrastructure.repository.UserEmailRepository;
import jakarta.mail.internet.MimeMessage;
import java.time.Duration;
import org.awaitility.Awaitility;
import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.api.extension.ExtensionContext.Namespace;
import org.junit.jupiter.api.extension.ExtensionContext.Store.CloseableResource;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.stream.function.StreamBridge;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.kafka.KafkaContainer;
import org.testcontainers.utility.DockerImageName;

@SpringBootTest
@Testcontainers
public abstract class BaseConsumerIntegrationTest {

  private static final int SMTP_PORT = 3025;
  private static final Duration EMAIL_TIMEOUT = Duration.ofSeconds(10);
  private static final Namespace NS = Namespace.create(BaseConsumerIntegrationTest.class);
  private static final String KEY = "greenmail";

  @Container
  static final KafkaContainer KAFKA =
      new KafkaContainer(DockerImageName.parse("apache/kafka:3.7.0"));

  @DynamicPropertySource
  static void kafkaProperties(DynamicPropertyRegistry registry) {
    registry.add("spring.cloud.stream.kafka.binder.brokers", KAFKA::getBootstrapServers);
  }

  @DynamicPropertySource
  static void mailProperties(DynamicPropertyRegistry registry) {
    registry.add("spring.mail.host", () -> "localhost");
    registry.add("spring.mail.port", () -> SMTP_PORT);
    registry.add("spring.mail.protocol", () -> "smtp");
    registry.add("spring.mail.properties.mail.smtp.auth", () -> "false");
    registry.add("spring.mail.properties.mail.smtp.starttls.enable", () -> "false");
  }

  static class GreenMailExtension implements BeforeAllCallback {

    @Override
    public void beforeAll(ExtensionContext context) {
      context
          .getRoot()
          .getStore(NS)
          .getOrComputeIfAbsent(
              KEY,
              k -> {
                GreenMail gm =
                    new GreenMail(
                        new ServerSetup(SMTP_PORT, "localhost", ServerSetup.PROTOCOL_SMTP));
                gm.setUser("test@habitquest.it", "test");
                gm.start();
                greenMail = gm;
                return new CloseableResource() {
                  @Override
                  public void close() {
                    gm.stop();
                  }
                };
              });

      if (greenMail == null) {
        CloseableResource wrapper =
            context.getRoot().getStore(NS).get(KEY, CloseableResource.class);
      }
    }
  }

  @RegisterExtension
  static final GreenMailExtension GREEN_MAIL_EXTENSION = new GreenMailExtension();

  protected static GreenMail greenMail;

  @Autowired protected StreamBridge streamBridge;
  @Autowired protected UserEmailRepository userEmailRepository;
  @Autowired protected GuildMemberRepository guildMemberRepository;

  protected void publish(String bindingName, Object payload) {
    streamBridge.send(bindingName, payload);
  }

  protected MimeMessage[] waitForEmails(int count) {
    Awaitility.await()
        .atMost(EMAIL_TIMEOUT)
        .untilAsserted(
            () -> assertThat(greenMail.getReceivedMessages()).hasSizeGreaterThanOrEqualTo(count));
    return greenMail.getReceivedMessages();
  }

  protected void resetGreenMail() {
    greenMail.reset();
  }

  protected String subjectOf(MimeMessage msg) {
    try {
      return msg.getSubject();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  protected String recipientOf(MimeMessage msg) {
    try {
      return msg.getAllRecipients()[0].toString();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  protected String bodyOf(MimeMessage msg) {
    try {
      return msg.getContent().toString();
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }
}
