package habitquest.guild.domain.guild;

public class UnauthorizedGuildOperationException extends RuntimeException {
  public UnauthorizedGuildOperationException(String requestorId, String operation) {
    super(
        "Member '"
            + requestorId
            + "' is not authorized to perform '"
            + operation
            + "' in this guild");
  }
}
